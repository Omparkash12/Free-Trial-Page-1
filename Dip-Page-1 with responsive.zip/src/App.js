import './App.css';
import Pages from './Pages/Pages/Pages';

function App() {
  return (
    <div className="">
      <Pages />
    </div>
  );
}

export default App;
